from pkg02 import *

stu = p01.Student()
stu.say()


inInit()
