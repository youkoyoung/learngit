from pkg01 import *


inInit()


stu = Student()