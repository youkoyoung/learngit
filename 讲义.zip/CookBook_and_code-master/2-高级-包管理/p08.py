import pkg01.p01


stu = pkg01.p01.Student()
stu.say()