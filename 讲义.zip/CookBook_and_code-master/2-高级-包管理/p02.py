import p01

stu = p01.Student("xiaojign", 19)

stu.say()

p01.sayHello()