from p01 import Student, sayHello


stu = Student()

stu.say()


sayHello()