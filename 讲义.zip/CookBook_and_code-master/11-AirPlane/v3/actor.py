
class Actor():
    def __init__(self):
        '''
        完成对飞行物基类的初始化工作
        '''




