# Git安装
- 官网：https://git-scm.com/downloads
- windows： 下载后双击安装
- Linux: 原则上可以从官网下载安装
- MacOS： 官网下载dmg安装文件，双击

# GIT基本使用
- 创建仓库命令 git init
- git add:向暂存区添加内容
- git commit -m "message for desc": 向仓库提交内容，一般注释信息是要求强制添加
- git status: 显示git当前状态
- git rm: 删除信息
- git log: 查看日志

# Github and  Bitbuckets
- github: 注册，创建项目/仓库， 推送
- bitbucket: 私有，使用方法类似
	- 克隆习题课git仓库到本地：git clone https://Augsnano@bitbucket.org/Augsnano/e_tulingxueyuan.git