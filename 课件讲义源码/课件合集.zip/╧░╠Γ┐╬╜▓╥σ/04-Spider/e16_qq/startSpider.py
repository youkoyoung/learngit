from scrapy import cmdline

cmdline.execute("scrapy crawl qq".split())