from scrapy import cmdline

cmdline.execute("scrapy crawl meiju".split())